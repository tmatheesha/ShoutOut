<!DOCTYPE html>
<html dir="ltr" lang="en-gb">
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1" />

<title>Gramziu Themes - Search</title>

	<link rel="alternate" type="application/atom+xml" title="Feed - Gramziu Themes" href="http://gramziu.pl/phpBB/feed.php" />			<link rel="alternate" type="application/atom+xml" title="Feed - New Topics" href="http://gramziu.pl/phpBB/feed.php?mode=topics" />			
<!--[if IE]><link rel="shortcut icon" href="./styles/hawiki/theme/images/favicon.ico"><![endif]-->
<link rel="apple-touch-icon-precomposed" href="./styles/hawiki/theme/images/apple-touch-icon-precomposed.gif">
<link rel="icon" href="./styles/hawiki/theme/images/favicon.gif" />
<link rel="icon" sizes="16x16" href="./styles/hawiki/theme/images/favicon.ico" />


<!--
	phpBB style name: Hawiki
	Based on style:   prosilver (this is the default phpBB3 style)
	Original author:  Tom Beddard ( http://www.subBlue.com/ )
	Modified by:      Gramziu
-->

<link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700&amp;subset=latin,cyrillic-ext,latin-ext,cyrillic,greek-ext,greek,vietnamese" rel="stylesheet" type="text/css" media="screen, projection" />
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" media="screen, projection" />

<link href="./styles/hawiki/theme/stylesheet.css?assets_version=174" rel="stylesheet" type="text/css" media="screen, projection" />
<link href="./styles/hawiki/theme/colours.css?assets_version=174" rel="stylesheet" type="text/css" media="screen, projection" />
<link id="colour-variant" href="" rel="stylesheet" type="text/css" media="screen, projection" />
	

<style>
	* {
		transition: all 0.1s ease-in-out;
	}
	.colour-example {
		margin: 0 0 1px;
	}
	.colour-example:last-child {
		margin: 0;
	}
	.colour-example > a {
		color: #FFF;
		display: block;
		height: 40px;
		line-height: 40px;
		text-align: center;
		width: 100%;
	}
</style>




<script>
	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

	ga('create', 'UA-73438105-1', 'auto');
		ga('send', 'pageview');
</script>

</head>
<body id="phpbb" class="nojs notouch section-search ltr ">


<div id="overall-wrap">
	<a id="top" class="anchor" accesskey="t"></a>
	<div id="wrap-head">
		<div id="site-nav" role="navigation">
			<div class="chunk">
				
				
				<ul class="site-nav" role="menubar">
					<li class="font-icon responsive-menu dropdown-container" data-skip-responsive="true">
						<a href="#" class="responsive-menu-link dropdown-trigger"><i class="fa fa-bars"></i><span class="nav-rh-2">Quick links</span></a>
						<div class="dropdown hidden">
							<div class="pointer"><div class="pointer-inner"></div></div>
							<ul class="dropdown-contents" role="menu">
								
																	<li class="separator"></li>
																																				<li class="font-icon icon-search-unanswered"><a href="./search.php?search_id=unanswered" role="menuitem"><i class="fa fa-file-o"></i>Unanswered posts</a></li>
									<li class="font-icon icon-search-active"><a href="./search.php?search_id=active_topics" role="menuitem"><i class="fa fa-fire"></i>Active topics</a></li>
																<li class="separator site-menu"></li>

								<li data-skip-responsive="true" class="site-menu"><a href="./faq.php" rel="help" title="Frequently Asked Questions">FAQ</a></li>
<li class="site-menu">
	<a href="#" title="Example">Drop Down</a>
	<ul>
		<li><a href="#">Lorem ipsum</a></li>
		<li><a href="#">Welcome to phpBB3</a></li>
		<li><a href="#">Frequently Asked Questions</a></li>
		<li><a href="#">BBCode example</a></li>
	</ul>
</li>

															</ul>
						</div>
					</li>

										
									<li class="font-icon rightside"  data-skip-responsive="true"><a href="./ucp.php?mode=login" title="Login" accesskey="x" role="menuitem"><i class="fa fa-power-off"></i><span class="nav-rh-2">Login</span></a></li>
										<li class="font-icon rightside" data-skip-responsive="true"><a href="./ucp.php?mode=register" role="menuitem"><i class="fa fa-pencil-square-o"></i><span class="nav-rh-2">Register</span></a></li>
																		</ul>
			</div>
		</div>

		<div id="site-header" role="banner">
			<div class="chunk">
				<div id="site-logo">
					<a class="site-logo" href="./index.php" title="Board index"></a>
					<p class="skiplink"><a href="#start_here">Skip to content</a></p>
				</div>

				<ul id="site-menu">
					<li data-skip-responsive="true" class="site-menu"><a href="./faq.php" rel="help" title="Frequently Asked Questions">FAQ</a></li>
<li class="site-menu">
	<a href="#" title="Example">Drop Down</a>
	<ul>
		<li><a href="#">Lorem ipsum</a></li>
		<li><a href="#">Welcome to phpBB3</a></li>
		<li><a href="#">Frequently Asked Questions</a></li>
		<li><a href="#">BBCode example</a></li>
	</ul>
</li>
				</ul>

				
							</div>
		</div>
	</div>

	
	<a id="start_here" class="anchor"></a>
		
		
<div id="wrap-subhead">
	<div class="chunk">

		<div id="subhead-title">
			<h2 class="solo">Search</h2>
		</div>

		<ul id="breadcrumbs" role="menubar">
									<li class="breadcrumbs rightside">
												<span class="crumb"><a href="./index.php" accesskey="h" itemtype="http://data-vocabulary.org/Breadcrumb" itemscope="" data-navbar-reference="index">Board index</a></span>
											</li>
					</ul>

	</div>
</div>

<div id="wrap-body">
	<div class="chunk">

		
		<form method="get" action="./search.php" data-focus="keywords">

		<div class="panel">
			<div class="inner">
			<h3>Search query</h3>

			
			<fieldset>

			
			<dl>
				<dt><label for="keywords">Search for keywords:</label><br /><span>Place <strong>+</strong> in front of a word which must be found and <strong>-</strong> in front of a word which must not be found. Put a list of words separated by <strong>|</strong> into brackets if only one of the words must be found. Use * as a wildcard for partial matches.</span></dt>
				<dd><input type="search" class="inputbox" name="keywords" id="keywords" size="40" title="Search for keywords" /></dd>
				<dd><label for="terms1"><input type="radio" name="terms" id="terms1" value="all" checked="checked" /> Search for all terms or use query as entered</label></dd>
				<dd><label for="terms2"><input type="radio" name="terms" id="terms2" value="any" /> Search for any terms</label></dd>
			</dl>
			<dl>
				<dt><label for="author">Search for author:</label><br /><span>Use * as a wildcard for partial matches.</span></dt>
				<dd><input type="search" class="inputbox" name="author" id="author" size="40" title="Search for author" /></dd>
			</dl>

			
			</fieldset>

			
			</div>
		</div>

		<div class="panel bg2">
			<div class="inner">

			<h3>Search options</h3>

			
			<fieldset>

			
			<dl>
				<dt><label for="search_forum">Search in forums:</label><br /><span>Select the forum or forums you wish to search in. Subforums are searched automatically if you do not disable “search subforums“ below.</span></dt>
				<dd><select name="fid[]" id="search_forum" multiple="multiple" size="8" title="Search in forums"><option value="1">Main</option><option value="2">&nbsp; &nbsp;Informations</option><option value="3">&nbsp; &nbsp;General examples</option><option value="6">Themes</option><option value="7">&nbsp; &nbsp;Hawiki</option><option value="8">&nbsp; &nbsp;Ariki</option><option value="9">&nbsp; &nbsp;Anami</option><option value="10">Examples</option><option value="11">&nbsp; &nbsp;Forum with long description</option><option value="12">&nbsp; &nbsp;Forum with long description and subforums</option><option value="13">&nbsp; &nbsp;&nbsp; &nbsp;First subforum</option><option value="14">&nbsp; &nbsp;&nbsp; &nbsp;Second subforum</option><option value="16">&nbsp; &nbsp;Locked forum with short description</option><option value="17">&nbsp; &nbsp;Locked forum with short description and moderator</option><option value="4">Other</option></select></dd>
			</dl>
			<dl>
				<dt><label for="search_child1">Search subforums:</label></dt>
				<dd>
					<label for="search_child1"><input type="radio" name="sc" id="search_child1" value="1" checked="checked" /> Yes</label>
					<label for="search_child2"><input type="radio" name="sc" id="search_child2" value="0" /> No</label>
				</dd>
			</dl>
			<dl>
				<dt><label for="sf1">Search within:</label></dt>
				<dd><label for="sf1"><input type="radio" name="sf" id="sf1" value="all" checked="checked" /> Post subjects and message text</label></dd>
				<dd><label for="sf2"><input type="radio" name="sf" id="sf2" value="msgonly" /> Message text only</label></dd>
				<dd><label for="sf3"><input type="radio" name="sf" id="sf3" value="titleonly" /> Topic titles only</label></dd>
				<dd><label for="sf4"><input type="radio" name="sf" id="sf4" value="firstpost" /> First post of topics only</label></dd>
			</dl>

			
			<hr class="dashed" />

			
			<dl>
				<dt><label for="show_results1">Display results as:</label></dt>
				<dd>
					<label for="show_results1"><input type="radio" name="sr" id="show_results1" value="posts" checked="checked" /> Posts</label>
					<label for="show_results2"><input type="radio" name="sr" id="show_results2" value="topics" /> Topics</label>
				</dd>
			</dl>
			<dl>
				<dt><label for="sd">Sort results by:</label></dt>
				<dd><select name="sk" id="sk"><option value="a">Author</option><option value="t" selected="selected">Post time</option><option value="f">Forum</option><option value="i">Topic title</option><option value="s">Post subject</option></select>&nbsp;
					<label for="sa"><input type="radio" name="sd" id="sa" value="a" /> Ascending</label>
					<label for="sd"><input type="radio" name="sd" id="sd-a" value="d" checked="checked" /> Descending</label>
				</dd>
			</dl>
			<dl>
				<dt><label>Limit results to previous:</label></dt>
				<dd><select name="st" id="st"><option value="0" selected="selected">All results</option><option value="1">1 day</option><option value="7">7 days</option><option value="14">2 weeks</option><option value="30">1 month</option><option value="90">3 months</option><option value="180">6 months</option><option value="365">1 year</option></select></dd>
			</dl>
			<dl>
				<dt><label>Return first:</label></dt>
				<dd><select name="ch" id="ch" title="Return first"><option value="-1">All available</option><option value="0">0</option><option value="25">25</option><option value="50">50</option><option value="100">100</option><option value="200">200</option><option value="300" selected="selected">300</option><option value="400">400</option><option value="500">500</option><option value="600">600</option><option value="700">700</option><option value="800">800</option><option value="900">900</option><option value="1000">1000</option></select> characters of posts</dd>
			</dl>

			
			</fieldset>

			
			</div>
		</div>

		<div class="panel bg3">
			<div class="inner">

			<fieldset class="submit-buttons">
				<input type="hidden" name="t" value="0" />
<input type="reset" value="Reset" name="reset" class="button2" />&nbsp;
				<input type="submit" name="submit" value="Search" class="button1" />
			</fieldset>

			</div>
		</div>

		</form>

		
		
		
		
	</div>
</div>

		
	
	<div id="wrap-footer">

		<div id="site-footer-area">
	<div class="chunk">
		<div class="grid-3">
			<h5>About us</h5>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
		</div>
		<div class="grid-3">
			<h5>You Must Know</h5>
			<ul>
				<li>
					<a href="#">Our Rules</a>
				</li>
				<li>
					<a href="#">Frequently Asked Questions</a>
				</li>
				<li>
					<a href="#">BBCode example</a>
				</li>
				<li>
					<a href="#">Lorem ipsum</a>
				</li>
				<li>
					<a href="#">Welcome to phpBB3</a>
				</li>
			</ul>
		</div>
		<div class="grid-3">
			<h5>Contact Us</h5>
			<ul class="get-in-touch">
				<li>
					<span>
					<span>Administrator e-mail:</span>
					alfa@domain.localhost
					</span>
				</li>
				<li>
					<span>
					<span>Moderator e-mail:</span>
					beta@domain.localhost
					<span></span>
					</span>
				</li>
			</ul>
			<h5>Social Links</h5>
			<ul class="cfooter-social">
				<li>
					<a href="#"><i class="fa fa-tumblr"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-instagram"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-pinterest"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-facebook"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-github"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-dropbox"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-steam"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-twitch"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-twitter"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-foursquare"></i></a>
				</li>
			</ul>
		</div>
	</div>
</div>

		<div id="site-footer-nav" role="navigation">
			<div class="chunk">
				<ul class="site-footer-nav" role="menubar">
					<li class="small-icon icon-home breadcrumbs">
																		<span class="crumb"><a href="./index.php" data-navbar-reference="index">Board index</a></span>
											</li>
																<li class="rightside"><a href="./ucp.php?mode=delete_cookies" data-ajax="true" data-refresh="true" role="menuitem">Delete all board cookies</a></li>
																					<li class="rightside" data-last-responsive="true"><a href="./memberlist.php?mode=team" role="menuitem">The team</a></li>										<li class="rightside" data-last-responsive="true"><a href="./memberlist.php?mode=contactadmin" role="menuitem">Contact us</a></li>				</ul>
			</div>
		</div>

		<div id="site-footer" role="contentinfo">
			<div class="chunk">
				<div class="grid-2">
										Powered by <a href="https://www.phpbb.com/">phpBB</a>&reg; Forum Software &copy; phpBB Limited
					<br />Hawiki Theme by <a href="http://themeforest.net/user/Gramziu">Gramziu</a>
																			</div>
				<div class="grid-2 ar">
										All times are <abbr title="UTC">UTC</abbr>
									</div>
			</div>
		</div>

		<div id="darkenwrapper" data-ajax-error-title="AJAX error" data-ajax-error-text="Something went wrong when processing your request." data-ajax-error-text-abort="User aborted request." data-ajax-error-text-timeout="Your request timed out; please try again." data-ajax-error-text-parsererror="Something went wrong with the request and the server returned an invalid reply.">
			<div id="darken">&nbsp;</div>
		</div>

		<div id="phpbb_alert" class="phpbb_alert" data-l-err="Error" data-l-timeout-processing-req="Request timed out.">
			<a href="#" class="alert_close"></a>
			<h3 class="alert_title">&nbsp;</h3><p class="alert_text"></p>
		</div>
		<div id="phpbb_confirm" class="phpbb_alert">
			<a href="#" class="alert_close"></a>
			<div class="alert_text"></div>
		</div>

		<div style="display: none;">
			<a id="bottom" class="anchor" accesskey="z"></a>
					</div>
</div>

<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script type="text/javascript">window.jQuery || document.write('\x3Cscript src="./assets/javascript/jquery.min.js?assets_version=174">\x3C/script>');</script><script type="text/javascript" src="./assets/javascript/core.js?assets_version=174"></script>

<script>
	$(function() {
		$("#st, #sd, #sk, #ch").chosen({
			disable_search: true,
			width: "auto"
		});
	});
</script>

<script>
	$(function() {

		var sidebarRecentPostDiv = document.getElementById("sidebar-recent-posts");

		$.get('http://gramziu.pl/phpBB/feed.php', function (data) {
			$(data).find("entry").each(function (i) {
				var el = $(this);
				var entryWrap = document.createElement("div");

				var entryTitle = document.createElement("a");
				var entryAuthor = document.createElement("span");
				var entryContent = document.createElement("span");

				entryTitle.className = ("sidebar-recent-title");
				entryAuthor.className = ("sidebar-recent-author");
				entryContent.className = ("sidebar-recent-content");

				function cutText(name) {
					var elementText = el.find(name).text();

					if (name == "title") {
						elementText = elementText.substring(elementText.indexOf("•") + 2);
					} else if (name == "content") {
						elementText = elementText.replace(/(<([^>]+)>)/ig,"");
					}

					if (elementText.length > 50) {
						return elementText.substr(0, 50);
					} else {
						return elementText;	
					};
				};

				entryTitle.textContent = cutText("title");
				entryAuthor.textContent = "by " + cutText("author");
				entryContent.textContent = cutText("content");
				entryURL = el.find("id").text();

				$(entryTitle).attr("href", entryURL);

				entryWrap.appendChild(entryTitle);
				entryWrap.appendChild(entryAuthor);
				entryWrap.appendChild(entryContent);

				sidebarRecentPostDiv.appendChild(entryWrap);

				if (++i >= 5) {
					return false;
				}
			});
		});

	});
</script>


<script type="text/javascript" src="./styles/hawiki/template/forum_fn.js?assets_version=174"></script>

<script type="text/javascript" src="./styles/hawiki/template/ajax.js?assets_version=174"></script>

<script type="text/javascript" src="./styles/hawiki/template/chosen.jquery.min.js?assets_version=174"></script>




</div>

</body>
</html>
