<!DOCTYPE html>
<html dir="ltr" lang="en-gb">
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1" />

<title>Gramziu Themes - Index page</title>

	<link rel="alternate" type="application/atom+xml" title="Feed - Gramziu Themes" href="http://gramziu.pl/phpBB/feed.php" />			<link rel="alternate" type="application/atom+xml" title="Feed - New Topics" href="http://gramziu.pl/phpBB/feed.php?mode=topics" />			
<!--[if IE]><link rel="shortcut icon" href="./styles/hawiki/theme/images/favicon.ico"><![endif]-->
<link rel="apple-touch-icon-precomposed" href="./styles/hawiki/theme/images/apple-touch-icon-precomposed.gif">
<link rel="icon" href="./styles/hawiki/theme/images/favicon.gif" />
<link rel="icon" sizes="16x16" href="./styles/hawiki/theme/images/favicon.ico" />


<!--
	phpBB style name: Hawiki
	Based on style:   prosilver (this is the default phpBB3 style)
	Original author:  Tom Beddard ( http://www.subBlue.com/ )
	Modified by:      Gramziu
-->

<link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700&amp;subset=latin,cyrillic-ext,latin-ext,cyrillic,greek-ext,greek,vietnamese" rel="stylesheet" type="text/css" media="screen, projection" />
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" media="screen, projection" />

<link href="./styles/hawiki/theme/stylesheet.css?assets_version=174" rel="stylesheet" type="text/css" media="screen, projection" />
<link href="./styles/hawiki/theme/colours.css?assets_version=174" rel="stylesheet" type="text/css" media="screen, projection" />
<link id="colour-variant" href="" rel="stylesheet" type="text/css" media="screen, projection" />
	

<style>
	* {
		transition: all 0.1s ease-in-out;
	}
	.colour-example {
		margin: 0 0 1px;
	}
	.colour-example:last-child {
		margin: 0;
	}
	.colour-example > a {
		color: #FFF;
		display: block;
		height: 40px;
		line-height: 40px;
		text-align: center;
		width: 100%;
	}
</style>




<script>
	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

	ga('create', 'UA-73438105-1', 'auto');
		ga('send', 'pageview');
</script>

</head>
<body id="phpbb" class="nojs notouch section-index ltr ">


<div id="overall-wrap">
	<a id="top" class="anchor" accesskey="t"></a>
	<div id="wrap-head">
		<div id="site-nav" role="navigation">
			<div class="chunk">
				
				
				<ul class="site-nav" role="menubar">
					<li class="font-icon responsive-menu dropdown-container" data-skip-responsive="true">
						<a href="#" class="responsive-menu-link dropdown-trigger"><i class="fa fa-bars"></i><span class="nav-rh-2">Quick links</span></a>
						<div class="dropdown hidden">
							<div class="pointer"><div class="pointer-inner"></div></div>
							<ul class="dropdown-contents" role="menu">
								
																	<li class="separator"></li>
																																				<li class="font-icon icon-search-unanswered"><a href="./search.php?search_id=unanswered" role="menuitem"><i class="fa fa-file-o"></i>Unanswered posts</a></li>
									<li class="font-icon icon-search-active"><a href="./search.php?search_id=active_topics" role="menuitem"><i class="fa fa-fire"></i>Active topics</a></li>
																<li class="separator site-menu"></li>

								<li data-skip-responsive="true" class="site-menu"><a href="./faq.php" rel="help" title="Frequently Asked Questions">FAQ</a></li>
<li class="site-menu">
	<a href="#" title="Example">Drop Down</a>
	<ul>
		<li><a href="#">Lorem ipsum</a></li>
		<li><a href="#">Welcome to phpBB3</a></li>
		<li><a href="#">Frequently Asked Questions</a></li>
		<li><a href="#">BBCode example</a></li>
	</ul>
</li>

															</ul>
						</div>
					</li>

										
									<li class="font-icon rightside"  data-skip-responsive="true"><a href="./ucp.php?mode=login" title="Login" accesskey="x" role="menuitem"><i class="fa fa-power-off"></i><span class="nav-rh-2">Login</span></a></li>
										<li class="font-icon rightside" data-skip-responsive="true"><a href="./ucp.php?mode=register" role="menuitem"><i class="fa fa-pencil-square-o"></i><span class="nav-rh-2">Register</span></a></li>
																		</ul>
			</div>
		</div>

		<div id="site-header" role="banner">
			<div class="chunk">
				<div id="site-logo">
					<a class="site-logo" href="./index.php" title="Board index"></a>
					<p class="skiplink"><a href="#start_here">Skip to content</a></p>
				</div>

				<ul id="site-menu">
					<li data-skip-responsive="true" class="site-menu"><a href="./faq.php" rel="help" title="Frequently Asked Questions">FAQ</a></li>
<li class="site-menu">
	<a href="#" title="Example">Drop Down</a>
	<ul>
		<li><a href="#">Lorem ipsum</a></li>
		<li><a href="#">Welcome to phpBB3</a></li>
		<li><a href="#">Frequently Asked Questions</a></li>
		<li><a href="#">BBCode example</a></li>
	</ul>
</li>
				</ul>

				
								<div id="site-search" role="search">
					<form action="./search.php" method="get">
						<fieldset>
							<input name="keywords" type="search" maxlength="128" title="Search for keywords" size="20" value="" placeholder="Search" /><button type="submit" title="Search"><i class="fa fa-search"></i></button>
						</fieldset>
					</form>
				</div>
							</div>
		</div>
	</div>

	
	<a id="start_here" class="anchor"></a>
		
		
<div id="wrap-subhead-main">
	<div class="chunk">

		<ul id="breadcrumbs-main" role="menubar">
									<li class="breadcrumbs">
												<span class="crumb"><a href="./index.php" accesskey="h" itemtype="http://data-vocabulary.org/Breadcrumb" itemscope="" data-navbar-reference="index">Board index</a></span>
											</li>
					</ul>

						
	</div>
</div>

<div id="wrap-body">
	<div class="chunk">

		<div id="sidebar">

	<div class="side-block">
		<img src="./styles/hawiki/theme/images/rate_it.jpg" alt="Rate it">
	</div>

		<div class="side-block side-login">
		<form method="post" action="./ucp.php?mode=login">
			<h4 class="side-block-head"><a href="./ucp.php?mode=login">Login</a>&nbsp; &bull; &nbsp;<a href="./ucp.php?mode=register">Register</a></h4>
			<div class="side-block-body">
				<fieldset>
					<input type="text" tabindex="1" name="username" id="username" size="10" class="inputbox" title="Username" placeholder="Username" /><input type="password" tabindex="2" name="password" id="password" size="10" class="inputbox" title="Password" autocomplete="off" placeholder="Password" />
					<br />
											<a href="./ucp.php?mode=sendpassword">I forgot my password</a>
																<label for="autologin" id="remember-me"><input type="checkbox" tabindex="4" name="autologin" id="autologin" />Remember me</label>
										<br />
					<input type="submit" tabindex="5" name="login" value="Login" class="button2" />
					<input type="hidden" name="redirect" value="./index.php?" />

				</fieldset>
			</div>
		</form>
	</div>
	
	<div class="side-block">
		<h4 class="side-block-head">Posts</h4>
		<div class="side-block-body" id="sidebar-recent-posts"></div>
	</div>

</div>

		<div id="forumlist">

			<div id="forumlist-inner">

				
	
				<div class="forabg">
			<div class="inner">
			<ul class="topiclist">
				<li class="header">

					
					<dl class="icon">
						<dt><div class="list-inner"><a href="./viewforum.php?f=1">Main</a></div></dt>
						<dd class="topics">Topics</dd>
						<dd class="posts">Posts</dd>
						<dd class="lastpost">Last post</dd>
					</dl>

					
				</li>
			</ul>
			<ul class="topiclist forums">
		
	
	
	
			
					<li class="row">
						<dl class="icon forum_read">
				<dt title="No unread posts">
										<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Informations" href="http://gramziu.pl/phpBB/feed.php?f=2"><img src="./styles/hawiki/theme/images/feed.gif" alt="Feed - Informations" /></a> -->
												<a href="./viewforum.php?f=2" class="forumtitle">Informations</a>
						<br />Everything you should know.												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>2</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">2 <dfn>Topics</dfn></dd>
					<dd class="posts">2 <dfn>Posts</dfn></dd>
					<dd class="lastpost">
						<dfn>Last post</dfn><a href="./viewtopic.php?f=2&amp;p=2#p2" title="Welcome" class="lastsubject">Welcome</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=2" style="color: #AA0000;" class="username-coloured">Gramziu</a>
						24 Feb 2015, 21:50					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl class="icon forum_read_locked">
				<dt title="Forum locked">
										<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - General examples" href="http://gramziu.pl/phpBB/feed.php?f=3"><img src="./styles/hawiki/theme/images/feed.gif" alt="Feed - General examples" /></a> -->
												<a href="./viewforum.php?f=3" class="forumtitle">General examples</a>
						<br />Examples of topics, you can see here how everything works.												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>6</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">6 <dfn>Topics</dfn></dd>
					<dd class="posts">45 <dfn>Posts</dfn></dd>
					<dd class="lastpost">
						<dfn>Last post</dfn><a href="./viewtopic.php?f=3&amp;p=69#p69" title="Re: Popular topic" class="lastsubject">Re: Popular topic</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=50" style="color: #00AA00;" class="username-coloured">Ramziu</a>
						07 Dec 2015, 20:03					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl class="icon forum_link">
				<dt title="No unread posts">
										<div class="list-inner">
						
												<a href="./viewforum.php?f=5" class="forumtitle">Gramziu themes on ThemeForest</a>
						<br />You can find Gramziu themes only on ThemeForest.												
												<div class="responsive-show" style="display: none;">
															Total redirects: <strong>25292</strong>
													</div>
											</div>
				</dt>
									<dd class="redirect">Total redirects: 25292</dd>
							</dl>
					</li>
			
	
				</ul>

			</div>
		</div>
	
				<div class="forabg">
			<div class="inner">
			<ul class="topiclist">
				<li class="header">

					
					<dl class="icon">
						<dt><div class="list-inner"><a href="./viewforum.php?f=6">Themes</a></div></dt>
						<dd class="topics">Topics</dd>
						<dd class="posts">Posts</dd>
						<dd class="lastpost">Last post</dd>
					</dl>

					
				</li>
			</ul>
			<ul class="topiclist forums">
		
	
	
	
			
					<li class="row">
						<dl class="icon forum_read">
				<dt title="No unread posts">
										<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Hawiki" href="http://gramziu.pl/phpBB/feed.php?f=7"><img src="./styles/hawiki/theme/images/feed.gif" alt="Feed - Hawiki" /></a> -->
												<a href="./viewforum.php?f=7" class="forumtitle">Hawiki</a>
						<br />Simple phpBB theme.												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>1</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">1 <dfn>Topics</dfn></dd>
					<dd class="posts">2 <dfn>Posts</dfn></dd>
					<dd class="lastpost">
						<dfn>Last post</dfn><a href="./viewtopic.php?f=7&amp;p=70#p70" title="Re: Sample" class="lastsubject">Re: Sample</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=51" class="username">Zamziu</a>
						07 Dec 2015, 20:20					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl class="icon forum_read">
				<dt title="No unread posts">
										<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Ariki" href="http://gramziu.pl/phpBB/feed.php?f=8"><img src="./styles/hawiki/theme/images/feed.gif" alt="Feed - Ariki" /></a> -->
												<a href="./viewforum.php?f=8" class="forumtitle">Ariki</a>
						<br />Colourful phpBB theme.												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>1</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">1 <dfn>Topics</dfn></dd>
					<dd class="posts">2 <dfn>Posts</dfn></dd>
					<dd class="lastpost">
						<dfn>Last post</dfn><a href="./viewtopic.php?f=8&amp;p=71#p71" title="Re: Example" class="lastsubject">Re: Example</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=52" class="username">Tamziu</a>
						07 Dec 2015, 20:36					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl class="icon forum_read">
				<dt title="No unread posts">
										<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Anami" href="http://gramziu.pl/phpBB/feed.php?f=9"><img src="./styles/hawiki/theme/images/feed.gif" alt="Feed - Anami" /></a> -->
												<a href="./viewforum.php?f=9" class="forumtitle">Anami</a>
						<br />Clear phpBB theme.												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>1</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">1 <dfn>Topics</dfn></dd>
					<dd class="posts">2 <dfn>Posts</dfn></dd>
					<dd class="lastpost">
						<dfn>Last post</dfn><a href="./viewtopic.php?f=9&amp;p=72#p72" title="Re: Lorem ipsum" class="lastsubject">Re: Lorem ipsum</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=53" class="username">Xamziu</a>
						07 Dec 2015, 20:40					</dd>
							</dl>
					</li>
			
	
				</ul>

			</div>
		</div>
	
				<div class="forabg">
			<div class="inner">
			<ul class="topiclist">
				<li class="header">

					
					<dl class="icon">
						<dt><div class="list-inner"><a href="./viewforum.php?f=10">Examples</a></div></dt>
						<dd class="topics">Topics</dd>
						<dd class="posts">Posts</dd>
						<dd class="lastpost">Last post</dd>
					</dl>

					
				</li>
			</ul>
			<ul class="topiclist forums">
		
	
	
	
			
					<li class="row">
						<dl class="icon forum_read">
				<dt title="No unread posts">
										<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Forum with long description" href="http://gramziu.pl/phpBB/feed.php?f=11"><img src="./styles/hawiki/theme/images/feed.gif" alt="Feed - Forum with long description" /></a> -->
												<a href="./viewforum.php?f=11" class="forumtitle">Forum with long description</a>
						<br />Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>1</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">1 <dfn>Topics</dfn></dd>
					<dd class="posts">2 <dfn>Posts</dfn></dd>
					<dd class="lastpost">
						<dfn>Last post</dfn><a href="./viewtopic.php?f=11&amp;p=77#p77" title="Re: Good topic" class="lastsubject">Re: Good topic</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=56" class="username">Kamziu</a>
						07 Dec 2015, 21:06					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl class="icon forum_read_subforum">
				<dt title="No unread posts">
										<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Forum with long description and subforums" href="http://gramziu.pl/phpBB/feed.php?f=12"><img src="./styles/hawiki/theme/images/feed.gif" alt="Feed - Forum with long description and subforums" /></a> -->
												<a href="./viewforum.php?f=12" class="forumtitle">Forum with long description and subforums</a>
						<br />Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.																										<br /><strong>Subforums:</strong>
															<a href="./viewforum.php?f=13" class="subforum read" title="No unread posts">First subforum</a>, 															<a href="./viewforum.php?f=14" class="subforum read" title="No unread posts">Second subforum</a>																				
												<div class="responsive-show" style="display: none;">
															Topics: <strong>1</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">1 <dfn>Topics</dfn></dd>
					<dd class="posts">2 <dfn>Posts</dfn></dd>
					<dd class="lastpost">
						<dfn>Last post</dfn><a href="./viewtopic.php?f=12&amp;p=73#p73" title="Re: Another example" class="lastsubject">Re: Another example</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=54" class="username">Famziu</a>
						07 Dec 2015, 20:42					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl class="icon forum_read_locked">
				<dt title="Forum locked">
										<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Locked forum with short description" href="http://gramziu.pl/phpBB/feed.php?f=16"><img src="./styles/hawiki/theme/images/feed.gif" alt="Feed - Locked forum with short description" /></a> -->
												<a href="./viewforum.php?f=16" class="forumtitle">Locked forum with short description</a>
						<br />Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>1</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">1 <dfn>Topics</dfn></dd>
					<dd class="posts">2 <dfn>Posts</dfn></dd>
					<dd class="lastpost">
						<dfn>Last post</dfn><a href="./viewtopic.php?f=16&amp;p=75#p75" title="Re: Next lorem ipsum text" class="lastsubject">Re: Next lorem ipsum text</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=50" style="color: #00AA00;" class="username-coloured">Ramziu</a>
						07 Dec 2015, 20:55					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl class="icon forum_read_locked">
				<dt title="Forum locked">
										<div class="list-inner">
						<!-- <a class="feed-icon-forum" title="Feed - Locked forum with short description and moderator" href="http://gramziu.pl/phpBB/feed.php?f=17"><img src="./styles/hawiki/theme/images/feed.gif" alt="Feed - Locked forum with short description and moderator" /></a> -->
												<a href="./viewforum.php?f=17" class="forumtitle">Locked forum with short description and moderator</a>
						<br />Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.													<br /><strong>Moderator:</strong> <a href="./memberlist.php?mode=viewprofile&amp;u=2" style="color: #AA0000;" class="username-coloured">Gramziu</a>
												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>1</strong>
													</div>
											</div>
				</dt>
									<dd class="topics">1 <dfn>Topics</dfn></dd>
					<dd class="posts">2 <dfn>Posts</dfn></dd>
					<dd class="lastpost">
						<dfn>Last post</dfn><a href="./viewtopic.php?f=17&amp;p=76#p76" title="Re: Hello!" class="lastsubject">Re: Hello!</a> <br />
						 
						by <a href="./memberlist.php?mode=viewprofile&amp;u=55" style="color: #00AA00;" class="username-coloured">Tramziu</a>
						07 Dec 2015, 21:01					</dd>
							</dl>
					</li>
			
				</ul>

			</div>
		</div>
		

				
				
									<div class="stat-block online-list">
						<h3>Who is online</h3>						<p>
														In total there are <strong>2</strong> users online :: 0 registered, 0 hidden and 2 guests (based on users active over the past 5 minutes)<br />Most users ever online was <strong>51</strong> on 11 Apr 2017, 10:11<br /> <br />Registered users: No registered users
							<br /><em>Legend: <a style="color:#AA0000" href="./memberlist.php?mode=group&amp;g=5">Administrators</a>, <a style="color:#00AA00" href="./memberlist.php?mode=group&amp;g=4">Global moderators</a>, <span style="color:#9E8DA7">Bots</span>, <a href="./memberlist.php?mode=group&amp;g=2">Registered users</a></em>													</p>
						<p id="online-list-stat">
														Total posts <strong>156</strong> &bull; Total topics <strong>26</strong> &bull; Total members <strong>1382</strong> &bull; Our newest member <strong><a href="./memberlist.php?mode=viewprofile&amp;u=1450" class="username">HowardBic</a></strong>
													</p>
					</div>
				
				
				
				
				
			</div>

		</div>

	</div>
</div>
	
		
	
	<div id="wrap-footer">

		<div id="site-footer-area">
	<div class="chunk">
		<div class="grid-3">
			<h5>About us</h5>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
		</div>
		<div class="grid-3">
			<h5>You Must Know</h5>
			<ul>
				<li>
					<a href="#">Our Rules</a>
				</li>
				<li>
					<a href="#">Frequently Asked Questions</a>
				</li>
				<li>
					<a href="#">BBCode example</a>
				</li>
				<li>
					<a href="#">Lorem ipsum</a>
				</li>
				<li>
					<a href="#">Welcome to phpBB3</a>
				</li>
			</ul>
		</div>
		<div class="grid-3">
			<h5>Contact Us</h5>
			<ul class="get-in-touch">
				<li>
					<span>
					<span>Administrator e-mail:</span>
					alfa@domain.localhost
					</span>
				</li>
				<li>
					<span>
					<span>Moderator e-mail:</span>
					beta@domain.localhost
					<span></span>
					</span>
				</li>
			</ul>
			<h5>Social Links</h5>
			<ul class="cfooter-social">
				<li>
					<a href="#"><i class="fa fa-tumblr"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-instagram"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-pinterest"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-facebook"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-github"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-dropbox"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-steam"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-twitch"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-twitter"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-foursquare"></i></a>
				</li>
			</ul>
		</div>
	</div>
</div>

		<div id="site-footer-nav" role="navigation">
			<div class="chunk">
				<ul class="site-footer-nav" role="menubar">
					<li class="small-icon icon-home breadcrumbs">
																		<span class="crumb"><a href="./index.php" data-navbar-reference="index">Board index</a></span>
											</li>
																<li class="rightside"><a href="./ucp.php?mode=delete_cookies" data-ajax="true" data-refresh="true" role="menuitem">Delete all board cookies</a></li>
																					<li class="rightside" data-last-responsive="true"><a href="./memberlist.php?mode=team" role="menuitem">The team</a></li>										<li class="rightside" data-last-responsive="true"><a href="./memberlist.php?mode=contactadmin" role="menuitem">Contact us</a></li>				</ul>
			</div>
		</div>

		<div id="site-footer" role="contentinfo">
			<div class="chunk">
				<div class="grid-2">
										Powered by <a href="https://www.phpbb.com/">phpBB</a>&reg; Forum Software &copy; phpBB Limited
					<br />Hawiki Theme by <a href="http://themeforest.net/user/Gramziu">Gramziu</a>
																			</div>
				<div class="grid-2 ar">
										All times are <abbr title="UTC">UTC</abbr>
									</div>
			</div>
		</div>

		<div id="darkenwrapper" data-ajax-error-title="AJAX error" data-ajax-error-text="Something went wrong when processing your request." data-ajax-error-text-abort="User aborted request." data-ajax-error-text-timeout="Your request timed out; please try again." data-ajax-error-text-parsererror="Something went wrong with the request and the server returned an invalid reply.">
			<div id="darken">&nbsp;</div>
		</div>

		<div id="phpbb_alert" class="phpbb_alert" data-l-err="Error" data-l-timeout-processing-req="Request timed out.">
			<a href="#" class="alert_close"></a>
			<h3 class="alert_title">&nbsp;</h3><p class="alert_text"></p>
		</div>
		<div id="phpbb_confirm" class="phpbb_alert">
			<a href="#" class="alert_close"></a>
			<div class="alert_text"></div>
		</div>

		<div style="display: none;">
			<a id="bottom" class="anchor" accesskey="z"></a>
					</div>
</div>

<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script type="text/javascript">window.jQuery || document.write('\x3Cscript src="./assets/javascript/jquery.min.js?assets_version=174">\x3C/script>');</script><script type="text/javascript" src="./assets/javascript/core.js?assets_version=174"></script>

<script>
	$(function() {
		$("#st, #sd, #sk, #ch").chosen({
			disable_search: true,
			width: "auto"
		});
	});
</script>

<script>
	$(function() {

		var sidebarRecentPostDiv = document.getElementById("sidebar-recent-posts");

		$.get('http://gramziu.pl/phpBB/feed.php', function (data) {
			$(data).find("entry").each(function (i) {
				var el = $(this);
				var entryWrap = document.createElement("div");

				var entryTitle = document.createElement("a");
				var entryAuthor = document.createElement("span");
				var entryContent = document.createElement("span");

				entryTitle.className = ("sidebar-recent-title");
				entryAuthor.className = ("sidebar-recent-author");
				entryContent.className = ("sidebar-recent-content");

				function cutText(name) {
					var elementText = el.find(name).text();

					if (name == "title") {
						elementText = elementText.substring(elementText.indexOf("•") + 2);
					} else if (name == "content") {
						elementText = elementText.replace(/(<([^>]+)>)/ig,"");
					}

					if (elementText.length > 50) {
						return elementText.substr(0, 50);
					} else {
						return elementText;	
					};
				};

				entryTitle.textContent = cutText("title");
				entryAuthor.textContent = "by " + cutText("author");
				entryContent.textContent = cutText("content");
				entryURL = el.find("id").text();

				$(entryTitle).attr("href", entryURL);

				entryWrap.appendChild(entryTitle);
				entryWrap.appendChild(entryAuthor);
				entryWrap.appendChild(entryContent);

				sidebarRecentPostDiv.appendChild(entryWrap);

				if (++i >= 5) {
					return false;
				}
			});
		});

	});
</script>


<script type="text/javascript" src="./styles/hawiki/template/forum_fn.js?assets_version=174"></script>

<script type="text/javascript" src="./styles/hawiki/template/ajax.js?assets_version=174"></script>

<script type="text/javascript" src="./styles/hawiki/template/chosen.jquery.min.js?assets_version=174"></script>




</div>

</body>
</html>
