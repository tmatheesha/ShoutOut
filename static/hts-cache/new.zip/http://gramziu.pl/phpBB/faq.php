<!DOCTYPE html>
<html dir="ltr" lang="en-gb">
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1" />

<title>Gramziu Themes - Frequently Asked Questions</title>

	<link rel="alternate" type="application/atom+xml" title="Feed - Gramziu Themes" href="http://gramziu.pl/phpBB/feed.php" />			<link rel="alternate" type="application/atom+xml" title="Feed - New Topics" href="http://gramziu.pl/phpBB/feed.php?mode=topics" />			
<!--[if IE]><link rel="shortcut icon" href="./styles/hawiki/theme/images/favicon.ico"><![endif]-->
<link rel="apple-touch-icon-precomposed" href="./styles/hawiki/theme/images/apple-touch-icon-precomposed.gif">
<link rel="icon" href="./styles/hawiki/theme/images/favicon.gif" />
<link rel="icon" sizes="16x16" href="./styles/hawiki/theme/images/favicon.ico" />


<!--
	phpBB style name: Hawiki
	Based on style:   prosilver (this is the default phpBB3 style)
	Original author:  Tom Beddard ( http://www.subBlue.com/ )
	Modified by:      Gramziu
-->

<link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700&amp;subset=latin,cyrillic-ext,latin-ext,cyrillic,greek-ext,greek,vietnamese" rel="stylesheet" type="text/css" media="screen, projection" />
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" media="screen, projection" />

<link href="./styles/hawiki/theme/stylesheet.css?assets_version=174" rel="stylesheet" type="text/css" media="screen, projection" />
<link href="./styles/hawiki/theme/colours.css?assets_version=174" rel="stylesheet" type="text/css" media="screen, projection" />
<link id="colour-variant" href="" rel="stylesheet" type="text/css" media="screen, projection" />
	

<style>
	* {
		transition: all 0.1s ease-in-out;
	}
	.colour-example {
		margin: 0 0 1px;
	}
	.colour-example:last-child {
		margin: 0;
	}
	.colour-example > a {
		color: #FFF;
		display: block;
		height: 40px;
		line-height: 40px;
		text-align: center;
		width: 100%;
	}
</style>




<script>
	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

	ga('create', 'UA-73438105-1', 'auto');
		ga('send', 'pageview');
</script>

</head>
<body id="phpbb" class="nojs notouch section-faq ltr ">


<div id="overall-wrap">
	<a id="top" class="anchor" accesskey="t"></a>
	<div id="wrap-head">
		<div id="site-nav" role="navigation">
			<div class="chunk">
				
				
				<ul class="site-nav" role="menubar">
					<li class="font-icon responsive-menu dropdown-container" data-skip-responsive="true">
						<a href="#" class="responsive-menu-link dropdown-trigger"><i class="fa fa-bars"></i><span class="nav-rh-2">Quick links</span></a>
						<div class="dropdown hidden">
							<div class="pointer"><div class="pointer-inner"></div></div>
							<ul class="dropdown-contents" role="menu">
								
																	<li class="separator"></li>
																																				<li class="font-icon icon-search-unanswered"><a href="./search.php?search_id=unanswered" role="menuitem"><i class="fa fa-file-o"></i>Unanswered posts</a></li>
									<li class="font-icon icon-search-active"><a href="./search.php?search_id=active_topics" role="menuitem"><i class="fa fa-fire"></i>Active topics</a></li>
																<li class="separator site-menu"></li>

								<li data-skip-responsive="true" class="site-menu"><a href="./faq.php" rel="help" title="Frequently Asked Questions">FAQ</a></li>
<li class="site-menu">
	<a href="#" title="Example">Drop Down</a>
	<ul>
		<li><a href="#">Lorem ipsum</a></li>
		<li><a href="#">Welcome to phpBB3</a></li>
		<li><a href="#">Frequently Asked Questions</a></li>
		<li><a href="#">BBCode example</a></li>
	</ul>
</li>

															</ul>
						</div>
					</li>

										
									<li class="font-icon rightside"  data-skip-responsive="true"><a href="./ucp.php?mode=login" title="Login" accesskey="x" role="menuitem"><i class="fa fa-power-off"></i><span class="nav-rh-2">Login</span></a></li>
										<li class="font-icon rightside" data-skip-responsive="true"><a href="./ucp.php?mode=register" role="menuitem"><i class="fa fa-pencil-square-o"></i><span class="nav-rh-2">Register</span></a></li>
																		</ul>
			</div>
		</div>

		<div id="site-header" role="banner">
			<div class="chunk">
				<div id="site-logo">
					<a class="site-logo" href="./index.php" title="Board index"></a>
					<p class="skiplink"><a href="#start_here">Skip to content</a></p>
				</div>

				<ul id="site-menu">
					<li data-skip-responsive="true" class="site-menu"><a href="./faq.php" rel="help" title="Frequently Asked Questions">FAQ</a></li>
<li class="site-menu">
	<a href="#" title="Example">Drop Down</a>
	<ul>
		<li><a href="#">Lorem ipsum</a></li>
		<li><a href="#">Welcome to phpBB3</a></li>
		<li><a href="#">Frequently Asked Questions</a></li>
		<li><a href="#">BBCode example</a></li>
	</ul>
</li>
				</ul>

				
								<div id="site-search" role="search">
					<form action="./search.php" method="get">
						<fieldset>
							<input name="keywords" type="search" maxlength="128" title="Search for keywords" size="20" value="" placeholder="Search" /><button type="submit" title="Search"><i class="fa fa-search"></i></button>
						</fieldset>
					</form>
				</div>
							</div>
		</div>
	</div>

	
	<a id="start_here" class="anchor"></a>
		
		
<div id="wrap-subhead">
	<div class="chunk">

		<div id="subhead-title">
			<h2 class="faq-title">Frequently Asked Questions</h2>
		</div>

		<ul id="breadcrumbs" role="menubar">
									<li class="breadcrumbs rightside">
												<span class="crumb"><a href="./index.php" accesskey="h" itemtype="http://data-vocabulary.org/Breadcrumb" itemscope="" data-navbar-reference="index">Board index</a></span>
											</li>
					</ul>

	</div>
</div>

<div id="wrap-body">
	<div class="chunk">

		<div class="panel bg2" id="faqlinks">
			<div class="inner">
				<div class="column1">
									
					<dl class="faq">
						<dt><strong>Login and Registration Issues</strong></dt>
													<dd><a href="#f0r0">Why do I need to register?</a></dd>
													<dd><a href="#f0r1">What is COPPA?</a></dd>
													<dd><a href="#f0r2">Why can’t I register?</a></dd>
													<dd><a href="#f0r3">I registered but cannot login!</a></dd>
													<dd><a href="#f0r4">Why can’t I login?</a></dd>
													<dd><a href="#f0r5">I registered in the past but cannot login any more?!</a></dd>
													<dd><a href="#f0r6">I’ve lost my password!</a></dd>
													<dd><a href="#f0r7">Why do I get logged off automatically?</a></dd>
													<dd><a href="#f0r8">What does the “Delete all board cookies” do?</a></dd>
											</dl>
									
					<dl class="faq">
						<dt><strong>User Preferences and settings</strong></dt>
													<dd><a href="#f1r0">How do I change my settings?</a></dd>
													<dd><a href="#f1r1">How do I prevent my username appearing in the online user listings?</a></dd>
													<dd><a href="#f1r2">The times are not correct!</a></dd>
													<dd><a href="#f1r3">I changed the timezone and the time is still wrong!</a></dd>
													<dd><a href="#f1r4">My language is not in the list!</a></dd>
													<dd><a href="#f1r5">What are the images next to my username?</a></dd>
													<dd><a href="#f1r6">How do I display an avatar?</a></dd>
													<dd><a href="#f1r7">What is my rank and how do I change it?</a></dd>
													<dd><a href="#f1r8">When I click the email link for a user it asks me to login?</a></dd>
											</dl>
									
					<dl class="faq">
						<dt><strong>Posting Issues</strong></dt>
													<dd><a href="#f2r0">How do I create a new topic or post a reply?</a></dd>
													<dd><a href="#f2r1">How do I edit or delete a post?</a></dd>
													<dd><a href="#f2r2">How do I add a signature to my post?</a></dd>
													<dd><a href="#f2r3">How do I create a poll?</a></dd>
													<dd><a href="#f2r4">Why can’t I add more poll options?</a></dd>
													<dd><a href="#f2r5">How do I edit or delete a poll?</a></dd>
													<dd><a href="#f2r6">Why can’t I access a forum?</a></dd>
													<dd><a href="#f2r7">Why can’t I add attachments?</a></dd>
													<dd><a href="#f2r8">Why did I receive a warning?</a></dd>
													<dd><a href="#f2r9">How can I report posts to a moderator?</a></dd>
													<dd><a href="#f2r10">What is the “Save” button for in topic posting?</a></dd>
													<dd><a href="#f2r11">Why does my post need to be approved?</a></dd>
													<dd><a href="#f2r12">How do I bump my topic?</a></dd>
											</dl>
									
					<dl class="faq">
						<dt><strong>Formatting and Topic Types</strong></dt>
													<dd><a href="#f3r0">What is BBCode?</a></dd>
													<dd><a href="#f3r1">Can I use HTML?</a></dd>
													<dd><a href="#f3r2">What are Smilies?</a></dd>
													<dd><a href="#f3r3">Can I post images?</a></dd>
													<dd><a href="#f3r4">What are global announcements?</a></dd>
													<dd><a href="#f3r5">What are announcements?</a></dd>
													<dd><a href="#f3r6">What are sticky topics?</a></dd>
													<dd><a href="#f3r7">What are locked topics?</a></dd>
													<dd><a href="#f3r8">What are topic icons?</a></dd>
											</dl>
															</div>

						<div class="column2">
					
					<dl class="faq">
						<dt><strong>User Levels and Groups</strong></dt>
													<dd><a href="#f4r0">What are Administrators?</a></dd>
													<dd><a href="#f4r1">What are Moderators?</a></dd>
													<dd><a href="#f4r2">What are usergroups?</a></dd>
													<dd><a href="#f4r3">Where are the usergroups and how do I join one?</a></dd>
													<dd><a href="#f4r4">How do I become a usergroup leader?</a></dd>
													<dd><a href="#f4r5">Why do some usergroups appear in a different colour?</a></dd>
													<dd><a href="#f4r6">What is a “Default usergroup”?</a></dd>
													<dd><a href="#f4r7">What is “The team” link?</a></dd>
											</dl>
									
					<dl class="faq">
						<dt><strong>Private Messaging</strong></dt>
													<dd><a href="#f5r0">I cannot send private messages!</a></dd>
													<dd><a href="#f5r1">I keep getting unwanted private messages!</a></dd>
													<dd><a href="#f5r2">I have received a spamming or abusive email from someone on this board!</a></dd>
											</dl>
									
					<dl class="faq">
						<dt><strong>Friends and Foes</strong></dt>
													<dd><a href="#f6r0">What are my Friends and Foes lists?</a></dd>
													<dd><a href="#f6r1">How can I add / remove users to my Friends or Foes list?</a></dd>
											</dl>
									
					<dl class="faq">
						<dt><strong>Searching the Forums</strong></dt>
													<dd><a href="#f7r0">How can I search a forum or forums?</a></dd>
													<dd><a href="#f7r1">Why does my search return no results?</a></dd>
													<dd><a href="#f7r2">Why does my search return a blank page!?</a></dd>
													<dd><a href="#f7r3">How do I search for members?</a></dd>
													<dd><a href="#f7r4">How can I find my own posts and topics?</a></dd>
											</dl>
									
					<dl class="faq">
						<dt><strong>Subscriptions and Bookmarks</strong></dt>
													<dd><a href="#f8r0">What is the difference between bookmarking and subscribing?</a></dd>
													<dd><a href="#f8r1">How do I bookmark or subscribe to specific topics?</a></dd>
													<dd><a href="#f8r2">How do I subscribe to specific forums?</a></dd>
													<dd><a href="#f8r3">How do I remove my subscriptions?</a></dd>
											</dl>
									
					<dl class="faq">
						<dt><strong>Attachments</strong></dt>
													<dd><a href="#f9r0">What attachments are allowed on this board?</a></dd>
													<dd><a href="#f9r1">How do I find all my attachments?</a></dd>
											</dl>
									
					<dl class="faq">
						<dt><strong>phpBB Issues</strong></dt>
													<dd><a href="#f10r0">Who wrote this bulletin board?</a></dd>
													<dd><a href="#f10r1">Why isn’t X feature available?</a></dd>
													<dd><a href="#f10r2">Who do I contact about abusive and/or legal matters related to this board?</a></dd>
													<dd><a href="#f10r3">How do I contact a board administrator?</a></dd>
											</dl>
								</div>
			</div>
		</div>

					<div class="panel bg1">
				<div class="inner">

				<div class="content">
					<h2 class="faq-title">Login and Registration Issues</h2>
											<dl class="faq">
							<dt id="f0r0"><strong>Why do I need to register?</strong></dt>
							<dd>You may not have to, it is up to the administrator of the board as to whether you need to register in order to post messages. However; registration will give you access to additional features not available to guest users such as definable avatar images, private messaging, emailing of fellow users, usergroup subscription, etc. It only takes a few moments to register so it is recommended you do so.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f0r1"><strong>What is COPPA?</strong></dt>
							<dd>COPPA, or the Children’s Online Privacy Protection Act of 1998, is a law in the United States requiring websites which can potentially collect information from minors under the age of 13 to have written parental consent or some other method of legal guardian acknowledgment, allowing the collection of personally identifiable information from a minor under the age of 13. If you are unsure if this applies to you as someone trying to register or to the website you are trying to register on, contact legal counsel for assistance. Please note that phpBB Limited and the owners of this board cannot provide legal advice and is not a point of contact for legal concerns of any kind, except as outlined in question “Who do I contact about abusive and/or legal matters related to this board?”.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f0r2"><strong>Why can’t I register?</strong></dt>
							<dd>It is possible a board administrator has disabled registration to prevent new visitors from signing up. A board administrator could have also banned your IP address or disallowed the username you are attempting to register. Contact a board administrator for assistance.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f0r3"><strong>I registered but cannot login!</strong></dt>
							<dd>First, check your username and password. If they are correct, then one of two things may have happened. If COPPA support is enabled and you specified being under 13 years old during registration, you will have to follow the instructions you received. Some boards will also require new registrations to be activated, either by yourself or by an administrator before you can logon; this information was present during registration. If you were sent an email, follow the instructions. If you did not receive an email, you may have provided an incorrect email address or the email may have been picked up by a spam filer. If you are sure the email address you provided is correct, try contacting an administrator.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f0r4"><strong>Why can’t I login?</strong></dt>
							<dd>There are several reasons why this could occur. First, ensure your username and password are correct. If they are, contact a board administrator to make sure you haven’t been banned. It is also possible the website owner has a configuration error on their end, and they would need to fix it.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f0r5"><strong>I registered in the past but cannot login any more?!</strong></dt>
							<dd>It is possible an administrator has deactivated or deleted your account for some reason. Also, many boards periodically remove users who have not posted for a long time to reduce the size of the database. If this has happened, try registering again and being more involved in discussions.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f0r6"><strong>I’ve lost my password!</strong></dt>
							<dd>Don’t panic! While your password cannot be retrieved, it can easily be reset. Visit the login page and click <em>I forgot my password</em>. Follow the instructions and you should be able to log in again shortly.<br />However, if you are not able to reset your password, contact a board administrator.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f0r7"><strong>Why do I get logged off automatically?</strong></dt>
							<dd>If you do not check the <em>Remember me</em> box when you login, the board will only keep you logged in for a preset time. This prevents misuse of your account by anyone else. To stay logged in, check the <em>Remember me</em> box during login. This is not recommended if you access the board from a shared computer, e.g. library, internet cafe, university computer lab, etc. If you do not see this checkbox, it means a board administrator has disabled this feature.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f0r8"><strong>What does the “Delete all board cookies” do?</strong></dt>
							<dd>“Delete all board cookies” deletes the cookies created by phpBB which keep you authenticated and logged into the board. Cookies also provide functions such as read tracking if they have been enabled by a board administrator. If you are having login or logout problems, deleting board cookies may help.</dd>
						</dl>
															</div>

				</div>
			</div>
					<div class="panel bg2">
				<div class="inner">

				<div class="content">
					<h2 class="faq-title">User Preferences and settings</h2>
											<dl class="faq">
							<dt id="f1r0"><strong>How do I change my settings?</strong></dt>
							<dd>If you are a registered user, all your settings are stored in the board database. To alter them, visit your User Control Panel; a link can usually be found by clicking on your username at the top of board pages. This system will allow you to change all your settings and preferences.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f1r1"><strong>How do I prevent my username appearing in the online user listings?</strong></dt>
							<dd>Within your User Control Panel, under “Board preferences”, you will find the option <em>Hide your online status</em>. Enable this option and you will only appear to the administrators, moderators and yourself. You will be counted as a hidden user.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f1r2"><strong>The times are not correct!</strong></dt>
							<dd>It is possible the time displayed is from a timezone different from the one you are in. If this is the case, visit your User Control Panel and change your timezone to match your particular area, e.g. London, Paris, New York, Sydney, etc. Please note that changing the timezone, like most settings, can only be done by registered users. If you are not registered, this is a good time to do so.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f1r3"><strong>I changed the timezone and the time is still wrong!</strong></dt>
							<dd>If you are sure you have set the timezone correctly and the time is still incorrect, then the time stored on the server clock is incorrect. Please notify an administrator to correct the problem.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f1r4"><strong>My language is not in the list!</strong></dt>
							<dd>Either the administrator has not installed your language or nobody has translated this board into your language. Try asking a board administrator if they can install the language pack you need. If the language pack does not exist, feel free to create a new translation. More information can be found at the <a href="https://www.phpbb.com/">phpBB</a>&reg; website.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f1r5"><strong>What are the images next to my username?</strong></dt>
							<dd>There are two images which may appear along with a username when viewing posts. One of them may be an image associated with your rank, generally in the form of stars, blocks or dots, indicating how many posts you have made or your status on the board. Another, usually larger, image is known as an avatar and is generally unique or personal to each user.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f1r6"><strong>How do I display an avatar?</strong></dt>
							<dd>Within your User Control Panel, under “Profile” you can add an avatar by using one of the four following methods: Gravatar, Gallery, Remote or Upload. It is up to the board administrator to enable avatars and to choose the way in which avatars can be made available. If you are unable to use avatars, contact a board administrator.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f1r7"><strong>What is my rank and how do I change it?</strong></dt>
							<dd>Ranks, which appear below your username, indicate the number of posts you have made or identify certain users, e.g. moderators and administrators. In general, you cannot directly change the wording of any board ranks as they are set by the board administrator. Please do not abuse the board by posting unnecessarily just to increase your rank. Most boards will not tolerate this and the moderator or administrator will simply lower your post count.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f1r8"><strong>When I click the email link for a user it asks me to login?</strong></dt>
							<dd>Only registered users can send email to other users via the built-in email form, and only if the administrator has enabled this feature. This is to prevent malicious use of the email system by anonymous users.</dd>
						</dl>
															</div>

				</div>
			</div>
					<div class="panel bg1">
				<div class="inner">

				<div class="content">
					<h2 class="faq-title">Posting Issues</h2>
											<dl class="faq">
							<dt id="f2r0"><strong>How do I create a new topic or post a reply?</strong></dt>
							<dd>To post a new topic in a forum, click "New Topic". To post a reply to a topic, click "Post Reply". You may need to register before you can post a message. A list of your permissions in each forum is available at the bottom of the forum and topic screens. Example: You can post new topics, You can post attachments, etc.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f2r1"><strong>How do I edit or delete a post?</strong></dt>
							<dd>Unless you are a board administrator or moderator, you can only edit or delete your own posts. You can edit a post by clicking the edit button for the relevant post, sometimes for only a limited time after the post was made. If someone has already replied to the post, you will find a small piece of text output below the post when you return to the topic which lists the number of times you edited it along with the date and time. This will only appear if someone has made a reply; it will not appear if a moderator or administrator edited the post, though they may leave a note as to why they’ve edited the post at their own discretion. Please note that normal users cannot delete a post once someone has replied.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f2r2"><strong>How do I add a signature to my post?</strong></dt>
							<dd>To add a signature to a post you must first create one via your User Control Panel. Once created, you can check the <em>Attach a signature</em> box on the posting form to add your signature. You can also add a signature by default to all your posts by checking the appropriate radio button in the User Control Panel. If you do so, you can still prevent a signature being added to individual posts by un-checking the add signature box within the posting form.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f2r3"><strong>How do I create a poll?</strong></dt>
							<dd>When posting a new topic or editing the first post of a topic, click the “Poll creation” tab below the main posting form; if you cannot see this, you do not have appropriate permissions to create polls. Enter a title and at least two options in the appropriate fields, making sure each option is on a separate line in the textarea. You can also set the number of options users may select during voting under “Options per user”, a time limit in days for the poll (0 for infinite duration) and lastly the option to allow users to amend their votes.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f2r4"><strong>Why can’t I add more poll options?</strong></dt>
							<dd>The limit for poll options is set by the board administrator. If you feel you need to add more options to your poll than the allowed amount, contact the board administrator.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f2r5"><strong>How do I edit or delete a poll?</strong></dt>
							<dd>As with posts, polls can only be edited by the original poster, a moderator or an administrator. To edit a poll, click to edit the first post in the topic; this always has the poll associated with it. If no one has cast a vote, users can delete the poll or edit any poll option. However, if members have already placed votes, only moderators or administrators can edit or delete it. This prevents the poll’s options from being changed mid-way through a poll.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f2r6"><strong>Why can’t I access a forum?</strong></dt>
							<dd>Some forums may be limited to certain users or groups. To view, read, post or perform another action you may need special permissions. Contact a moderator or board administrator to grant you access.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f2r7"><strong>Why can’t I add attachments?</strong></dt>
							<dd>Attachment permissions are granted on a per forum, per group, or per user basis. The board administrator may not have allowed attachments to be added for the specific forum you are posting in, or perhaps only certain groups can post attachments. Contact the board administrator if you are unsure about why you are unable to add attachments.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f2r8"><strong>Why did I receive a warning?</strong></dt>
							<dd>Each board administrator has their own set of rules for their site. If you have broken a rule, you may be issued a warning. Please note that this is the board administrator’s decision, and the phpBB Limited has nothing to do with the warnings on the given site. Contact the board administrator if you are unsure about why you were issued a warning.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f2r9"><strong>How can I report posts to a moderator?</strong></dt>
							<dd>If the board administrator has allowed it, you should see a button for reporting posts next to the post you wish to report. Clicking this will walk you through the steps necessary to report the post.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f2r10"><strong>What is the “Save” button for in topic posting?</strong></dt>
							<dd>This allows you to save drafts to be completed and submitted at a later date. To reload a saved draft, visit the User Control Panel.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f2r11"><strong>Why does my post need to be approved?</strong></dt>
							<dd>The board administrator may have decided that posts in the forum you are posting to require review before submission. It is also possible that the administrator has placed you in a group of users whose posts require review before submission. Please contact the board administrator for further details.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f2r12"><strong>How do I bump my topic?</strong></dt>
							<dd>By clicking the “Bump topic” link when you are viewing it, you can “bump” the topic to the top of the forum on the first page. However, if you do not see this, then topic bumping may be disabled or the time allowance between bumps has not yet been reached. It is also possible to bump the topic simply by replying to it, however, be sure to follow the board rules when doing so.</dd>
						</dl>
															</div>

				</div>
			</div>
					<div class="panel bg2">
				<div class="inner">

				<div class="content">
					<h2 class="faq-title">Formatting and Topic Types</h2>
											<dl class="faq">
							<dt id="f3r0"><strong>What is BBCode?</strong></dt>
							<dd>BBCode is a special implementation of HTML, offering great formatting control on particular objects in a post. The use of BBCode is granted by the administrator, but it can also be disabled on a per post basis from the posting form. BBCode itself is similar in style to HTML, but tags are enclosed in square brackets [ and ] rather than &lt; and &gt;. For more information on BBCode see the guide which can be accessed from the posting page.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f3r1"><strong>Can I use HTML?</strong></dt>
							<dd>No. It is not possible to post HTML on this board and have it rendered as HTML. Most formatting which can be carried out using HTML can be applied using BBCode instead.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f3r2"><strong>What are Smilies?</strong></dt>
							<dd>Smilies, or Emoticons, are small images which can be used to express a feeling using a short code, e.g. :) denotes happy, while :( denotes sad. The full list of emoticons can be seen in the posting form. Try not to overuse smilies, however, as they can quickly render a post unreadable and a moderator may edit them out or remove the post altogether. The board administrator may also have set a limit to the number of smilies you may use within a post.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f3r3"><strong>Can I post images?</strong></dt>
							<dd>Yes, images can be shown in your posts. If the administrator has allowed attachments, you may be able to upload the image to the board. Otherwise, you must link to an image stored on a publicly accessible web server, e.g. http://www.example.com/my-picture.gif. You cannot link to pictures stored on your own PC (unless it is a publicly accessible server) nor images stored behind authentication mechanisms, e.g. hotmail or yahoo mailboxes, password protected sites, etc. To display the image use the BBCode [img] tag.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f3r4"><strong>What are global announcements?</strong></dt>
							<dd>Global announcements contain important information and you should read them whenever possible. They will appear at the top of every forum and within your User Control Panel. Global announcement permissions are granted by the board administrator.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f3r5"><strong>What are announcements?</strong></dt>
							<dd>Announcements often contain important information for the forum you are currently reading and you should read them whenever possible. Announcements appear at the top of every page in the forum to which they are posted. As with global announcements, announcement permissions are granted by the board administrator.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f3r6"><strong>What are sticky topics?</strong></dt>
							<dd>Sticky topics within the forum appear below announcements and only on the first page. They are often quite important so you should read them whenever possible. As with announcements and global announcements, sticky topic permissions are granted by the board administrator.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f3r7"><strong>What are locked topics?</strong></dt>
							<dd>Locked topics are topics where users can no longer reply and any poll it contained was automatically ended. Topics may be locked for many reasons and were set this way by either the forum moderator or board administrator. You may also be able to lock your own topics depending on the permissions you are granted by the board administrator.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f3r8"><strong>What are topic icons?</strong></dt>
							<dd>Topic icons are author chosen images associated with posts to indicate their content. The ability to use topic icons depends on the permissions set by the board administrator.</dd>
						</dl>
															</div>

				</div>
			</div>
					<div class="panel bg1">
				<div class="inner">

				<div class="content">
					<h2 class="faq-title">User Levels and Groups</h2>
											<dl class="faq">
							<dt id="f4r0"><strong>What are Administrators?</strong></dt>
							<dd>Administrators are members assigned with the highest level of control over the entire board. These members can control all facets of board operation, including setting permissions, banning users, creating usergroups or moderators, etc., dependent upon the board founder and what permissions he or she has given the other administrators. They may also have full moderator capabilities in all forums, depending on the settings put forth by the board founder.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f4r1"><strong>What are Moderators?</strong></dt>
							<dd>Moderators are individuals (or groups of individuals) who look after the forums from day to day. They have the authority to edit or delete posts and lock, unlock, move, delete and split topics in the forum they moderate. Generally, moderators are present to prevent users from going off-topic or posting abusive or offensive material.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f4r2"><strong>What are usergroups?</strong></dt>
							<dd>Usergroups are groups of users that divide the community into manageable sections board administrators can work with. Each user can belong to several groups and each group can be assigned individual permissions. This provides an easy way for administrators to change permissions for many users at once, such as changing moderator permissions or granting users access to a private forum.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f4r3"><strong>Where are the usergroups and how do I join one?</strong></dt>
							<dd>You can view all usergroups via the “Usergroups” link within your User Control Panel. If you would like to join one, proceed by clicking the appropriate button. Not all groups have open access, however. Some may require approval to join, some may be closed and some may even have hidden memberships. If the group is open, you can join it by clicking the appropriate button. If a group requires approval to join you may request to join by clicking the appropriate button. The user group leader will need to approve your request and may ask why you want to join the group. Please do not harass a group leader if they reject your request; they will have their reasons.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f4r4"><strong>How do I become a usergroup leader?</strong></dt>
							<dd>A usergroup leader is usually assigned when usergroups are initially created by a board administrator. If you are interested in creating a usergroup, your first point of contact should be an administrator; try sending a private message.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f4r5"><strong>Why do some usergroups appear in a different colour?</strong></dt>
							<dd>It is possible for the board administrator to assign a colour to the members of a usergroup to make it easy to identify the members of this group.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f4r6"><strong>What is a “Default usergroup”?</strong></dt>
							<dd>If you are a member of more than one usergroup, your default is used to determine which group colour and group rank should be shown for you by default. The board administrator may grant you permission to change your default usergroup via your User Control Panel.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f4r7"><strong>What is “The team” link?</strong></dt>
							<dd>This page provides you with a list of board staff, including board administrators and moderators and other details such as the forums they moderate.</dd>
						</dl>
															</div>

				</div>
			</div>
					<div class="panel bg2">
				<div class="inner">

				<div class="content">
					<h2 class="faq-title">Private Messaging</h2>
											<dl class="faq">
							<dt id="f5r0"><strong>I cannot send private messages!</strong></dt>
							<dd>There are three reasons for this; you are not registered and/or not logged on, the board administrator has disabled private messaging for the entire board, or the board administrator has prevented you from sending messages. Contact a board administrator for more information.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f5r1"><strong>I keep getting unwanted private messages!</strong></dt>
							<dd>You can automatically delete private messages from a user by using message rules within your User Control Panel. If you are receiving abusive private messages from a particular user, report the messages to the moderators; they have the power to prevent a user from sending private messages.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f5r2"><strong>I have received a spamming or abusive email from someone on this board!</strong></dt>
							<dd>We are sorry to hear that. The email form feature of this board includes safeguards to try and track users who send such posts, so email the board administrator with a full copy of the email you received. It is very important that this includes the headers that contain the details of the user that sent the email. The board administrator can then take action.</dd>
						</dl>
															</div>

				</div>
			</div>
					<div class="panel bg1">
				<div class="inner">

				<div class="content">
					<h2 class="faq-title">Friends and Foes</h2>
											<dl class="faq">
							<dt id="f6r0"><strong>What are my Friends and Foes lists?</strong></dt>
							<dd>You can use these lists to organise other members of the board. Members added to your friends list will be listed within your User Control Panel for quick access to see their online status and to send them private messages. Subject to template support, posts from these users may also be highlighted. If you add a user to your foes list, any posts they make will be hidden by default.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f6r1"><strong>How can I add / remove users to my Friends or Foes list?</strong></dt>
							<dd>You can add users to your list in two ways. Within each user’s profile, there is a link to add them to either your Friend or Foe list. Alternatively, from your User Control Panel, you can directly add users by entering their member name. You may also remove users from your list using the same page.</dd>
						</dl>
															</div>

				</div>
			</div>
					<div class="panel bg2">
				<div class="inner">

				<div class="content">
					<h2 class="faq-title">Searching the Forums</h2>
											<dl class="faq">
							<dt id="f7r0"><strong>How can I search a forum or forums?</strong></dt>
							<dd>Enter a search term in the search box located on the index, forum or topic pages. Advanced search can be accessed by clicking the “Advance Search” link which is available on all pages on the forum. How to access the search may depend on the style used.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f7r1"><strong>Why does my search return no results?</strong></dt>
							<dd>Your search was probably too vague and included many common terms which are not indexed by phpBB. Be more specific and use the options available within Advanced search.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f7r2"><strong>Why does my search return a blank page!?</strong></dt>
							<dd>Your search returned too many results for the webserver to handle. Use “Advanced search” and be more specific in the terms used and forums that are to be searched.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f7r3"><strong>How do I search for members?</strong></dt>
							<dd>Visit to the “Members” page and click the “Find a member” link.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f7r4"><strong>How can I find my own posts and topics?</strong></dt>
							<dd>Your own posts can be retrieved either by clicking the “Show your posts” link within the User Control Panel or by clicking the “Search user’s posts” link via your own profile page or by clicking the “Quick links” menu at the top of the board. To search for your topics, use the Advanced search page and fill in the various options appropriately.</dd>
						</dl>
															</div>

				</div>
			</div>
					<div class="panel bg1">
				<div class="inner">

				<div class="content">
					<h2 class="faq-title">Subscriptions and Bookmarks</h2>
											<dl class="faq">
							<dt id="f8r0"><strong>What is the difference between bookmarking and subscribing?</strong></dt>
							<dd>In phpBB 3.0, bookmarking topics worked much like bookmarking in a web browser. You were not alerted when there was an update. As of phpBB 3.1, bookmarking is more like subscribing to a topic. You can be notified when a bookmarked topic is updated. Subscribing, however, will notify you when there is an update to a topic or forum on the board. Notification options for bookmarks and subscriptions can be configured in the User Control Panel, under “Board preferences”.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f8r1"><strong>How do I bookmark or subscribe to specific topics?</strong></dt>
							<dd>You can bookmark or subscribe to a specific topic by clicking the appropriate link in the “Topic tools” menu, conveniently located near the top and bottom of a topic discussion.<br />Replying to a topic with the “Notify me when a reply is posted” option checked will also subscribe you to the topic.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f8r2"><strong>How do I subscribe to specific forums?</strong></dt>
							<dd>To subscribe to a specific forum, click the “Subscribe forum” link, at the bottom of page, upon entering the forum.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f8r3"><strong>How do I remove my subscriptions?</strong></dt>
							<dd>To remove your subscriptions, go to your User Control Panel and follow the links to your subscriptions.</dd>
						</dl>
															</div>

				</div>
			</div>
					<div class="panel bg2">
				<div class="inner">

				<div class="content">
					<h2 class="faq-title">Attachments</h2>
											<dl class="faq">
							<dt id="f9r0"><strong>What attachments are allowed on this board?</strong></dt>
							<dd>Each board administrator can allow or disallow certain attachment types. If you are unsure what is allowed to be uploaded, contact the board administrator for assistance.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f9r1"><strong>How do I find all my attachments?</strong></dt>
							<dd>To find your list of attachments that you have uploaded, go to your User Control Panel and follow the links to the attachments section.</dd>
						</dl>
															</div>

				</div>
			</div>
					<div class="panel bg1">
				<div class="inner">

				<div class="content">
					<h2 class="faq-title">phpBB Issues</h2>
											<dl class="faq">
							<dt id="f10r0"><strong>Who wrote this bulletin board?</strong></dt>
							<dd>This software (in its unmodified form) is produced, released and is copyright <a href="https://www.phpbb.com/">phpBB Limited</a>. It is made available under the GNU General Public License, version 2 (GPL-2.0) and may be freely distributed. See <a href="https://www.phpbb.com/about/">About phpBB</a> for more details.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f10r1"><strong>Why isn’t X feature available?</strong></dt>
							<dd>This software was written by and licensed through phpBB Limited. If you believe a feature needs to be added please visit the <a href="https://www.phpbb.com/ideas/">phpBB Ideas Centre</a>, where you can upvote existing ideas or suggest new features.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f10r2"><strong>Who do I contact about abusive and/or legal matters related to this board?</strong></dt>
							<dd>Any of the administrators listed on the “The team” page should be an appropriate point of contact for your complaints. If this still gets no response then you should contact the owner of the domain (do a <a href="http://www.google.com/search?q=whois">whois lookup</a>) or, if this is running on a free service (e.g. Yahoo!, free.fr, f2s.com, etc.), the management or abuse department of that service. Please note that the phpBB Limited has <strong>absolutely no jurisdiction</strong> and cannot in any way be held liable over how, where or by whom this board is used. Do not contact the phpBB Limited in relation to any legal (cease and desist, liable, defamatory comment, etc.) matter <strong>not directly related</strong> to the phpBB.com website or the discrete software of phpBB itself. If you do email phpBB Limited <strong>about any third party</strong> use of this software then you should expect a terse response or no response at all.</dd>
						</dl>
						<hr class="dashed" />											<dl class="faq">
							<dt id="f10r3"><strong>How do I contact a board administrator?</strong></dt>
							<dd>All users of the board can use the “Contact us” form, if the option was enabled by the board administrator.<br />Members of the board can also use the “The team” link.</dd>
						</dl>
															</div>

				</div>
			</div>
		
		

	<div class="dropdown-container dropdown-container-right dropdown-up dropdown-left dropdown-button-control" id="jumpbox">
		<span title="Jump to" class="dropdown-trigger button dropdown-select">
			Jump to		</span>
		<div class="dropdown hidden">
			<div class="pointer"><div class="pointer-inner"></div></div>
			<ul class="dropdown-contents">
																			<li><a href="./viewforum.php?f=1">Main</a></li>
																<li>&nbsp; &nbsp;<a href="./viewforum.php?f=2">Informations</a></li>
																<li>&nbsp; &nbsp;<a href="./viewforum.php?f=3">General examples</a></li>
																<li>&nbsp; &nbsp;<a href="./viewforum.php?f=5">Gramziu themes on ThemeForest</a></li>
																<li><a href="./viewforum.php?f=6">Themes</a></li>
																<li>&nbsp; &nbsp;<a href="./viewforum.php?f=7">Hawiki</a></li>
																<li>&nbsp; &nbsp;<a href="./viewforum.php?f=8">Ariki</a></li>
																<li>&nbsp; &nbsp;<a href="./viewforum.php?f=9">Anami</a></li>
																<li><a href="./viewforum.php?f=10">Examples</a></li>
																<li>&nbsp; &nbsp;<a href="./viewforum.php?f=11">Forum with long description</a></li>
																<li>&nbsp; &nbsp;<a href="./viewforum.php?f=12">Forum with long description and subforums</a></li>
																<li>&nbsp; &nbsp;&nbsp; &nbsp;<a href="./viewforum.php?f=13">First subforum</a></li>
																<li>&nbsp; &nbsp;&nbsp; &nbsp;<a href="./viewforum.php?f=14">Second subforum</a></li>
																<li>&nbsp; &nbsp;<a href="./viewforum.php?f=16">Locked forum with short description</a></li>
																<li>&nbsp; &nbsp;<a href="./viewforum.php?f=17">Locked forum with short description and moderator</a></li>
																<li><a href="./viewforum.php?f=4">Other</a></li>
										</ul>
		</div>
	</div>
		
	</div>
</div>

		
	
	<div id="wrap-footer">

		<div id="site-footer-area">
	<div class="chunk">
		<div class="grid-3">
			<h5>About us</h5>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
		</div>
		<div class="grid-3">
			<h5>You Must Know</h5>
			<ul>
				<li>
					<a href="#">Our Rules</a>
				</li>
				<li>
					<a href="#">Frequently Asked Questions</a>
				</li>
				<li>
					<a href="#">BBCode example</a>
				</li>
				<li>
					<a href="#">Lorem ipsum</a>
				</li>
				<li>
					<a href="#">Welcome to phpBB3</a>
				</li>
			</ul>
		</div>
		<div class="grid-3">
			<h5>Contact Us</h5>
			<ul class="get-in-touch">
				<li>
					<span>
					<span>Administrator e-mail:</span>
					alfa@domain.localhost
					</span>
				</li>
				<li>
					<span>
					<span>Moderator e-mail:</span>
					beta@domain.localhost
					<span></span>
					</span>
				</li>
			</ul>
			<h5>Social Links</h5>
			<ul class="cfooter-social">
				<li>
					<a href="#"><i class="fa fa-tumblr"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-instagram"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-pinterest"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-facebook"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-github"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-dropbox"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-steam"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-twitch"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-twitter"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-foursquare"></i></a>
				</li>
			</ul>
		</div>
	</div>
</div>

		<div id="site-footer-nav" role="navigation">
			<div class="chunk">
				<ul class="site-footer-nav" role="menubar">
					<li class="small-icon icon-home breadcrumbs">
																		<span class="crumb"><a href="./index.php" data-navbar-reference="index">Board index</a></span>
											</li>
																<li class="rightside"><a href="./ucp.php?mode=delete_cookies" data-ajax="true" data-refresh="true" role="menuitem">Delete all board cookies</a></li>
																					<li class="rightside" data-last-responsive="true"><a href="./memberlist.php?mode=team" role="menuitem">The team</a></li>										<li class="rightside" data-last-responsive="true"><a href="./memberlist.php?mode=contactadmin" role="menuitem">Contact us</a></li>				</ul>
			</div>
		</div>

		<div id="site-footer" role="contentinfo">
			<div class="chunk">
				<div class="grid-2">
										Powered by <a href="https://www.phpbb.com/">phpBB</a>&reg; Forum Software &copy; phpBB Limited
					<br />Hawiki Theme by <a href="http://themeforest.net/user/Gramziu">Gramziu</a>
																			</div>
				<div class="grid-2 ar">
										All times are <abbr title="UTC">UTC</abbr>
									</div>
			</div>
		</div>

		<div id="darkenwrapper" data-ajax-error-title="AJAX error" data-ajax-error-text="Something went wrong when processing your request." data-ajax-error-text-abort="User aborted request." data-ajax-error-text-timeout="Your request timed out; please try again." data-ajax-error-text-parsererror="Something went wrong with the request and the server returned an invalid reply.">
			<div id="darken">&nbsp;</div>
		</div>

		<div id="phpbb_alert" class="phpbb_alert" data-l-err="Error" data-l-timeout-processing-req="Request timed out.">
			<a href="#" class="alert_close"></a>
			<h3 class="alert_title">&nbsp;</h3><p class="alert_text"></p>
		</div>
		<div id="phpbb_confirm" class="phpbb_alert">
			<a href="#" class="alert_close"></a>
			<div class="alert_text"></div>
		</div>

		<div style="display: none;">
			<a id="bottom" class="anchor" accesskey="z"></a>
					</div>
</div>

<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script type="text/javascript">window.jQuery || document.write('\x3Cscript src="./assets/javascript/jquery.min.js?assets_version=174">\x3C/script>');</script><script type="text/javascript" src="./assets/javascript/core.js?assets_version=174"></script>

<script>
	$(function() {
		$("#st, #sd, #sk, #ch").chosen({
			disable_search: true,
			width: "auto"
		});
	});
</script>

<script>
	$(function() {

		var sidebarRecentPostDiv = document.getElementById("sidebar-recent-posts");

		$.get('http://gramziu.pl/phpBB/feed.php', function (data) {
			$(data).find("entry").each(function (i) {
				var el = $(this);
				var entryWrap = document.createElement("div");

				var entryTitle = document.createElement("a");
				var entryAuthor = document.createElement("span");
				var entryContent = document.createElement("span");

				entryTitle.className = ("sidebar-recent-title");
				entryAuthor.className = ("sidebar-recent-author");
				entryContent.className = ("sidebar-recent-content");

				function cutText(name) {
					var elementText = el.find(name).text();

					if (name == "title") {
						elementText = elementText.substring(elementText.indexOf("•") + 2);
					} else if (name == "content") {
						elementText = elementText.replace(/(<([^>]+)>)/ig,"");
					}

					if (elementText.length > 50) {
						return elementText.substr(0, 50);
					} else {
						return elementText;	
					};
				};

				entryTitle.textContent = cutText("title");
				entryAuthor.textContent = "by " + cutText("author");
				entryContent.textContent = cutText("content");
				entryURL = el.find("id").text();

				$(entryTitle).attr("href", entryURL);

				entryWrap.appendChild(entryTitle);
				entryWrap.appendChild(entryAuthor);
				entryWrap.appendChild(entryContent);

				sidebarRecentPostDiv.appendChild(entryWrap);

				if (++i >= 5) {
					return false;
				}
			});
		});

	});
</script>


<script type="text/javascript" src="./styles/hawiki/template/forum_fn.js?assets_version=174"></script>

<script type="text/javascript" src="./styles/hawiki/template/ajax.js?assets_version=174"></script>

<script type="text/javascript" src="./styles/hawiki/template/chosen.jquery.min.js?assets_version=174"></script>




</div>

</body>
</html>
